#!/bin/sh

if [ "$CVU_HOME" == "" ];then
	echo "please set up CVU_HOME"
	exit 1;
fi;

mv $CVU_HOME/bin/lsnodes $CVU_HOME/bin/lsnodes.orig
cp -p bin/lsnodes $CVU_HOME/bin/lsnodes
chmod 775 $CVU_HOME/bin/lsnodes
mv $CVU_HOME/crs/lib/env_has.mk $CVU_HOME/crs/lib/env_has.mk.orig
cp -p crs/lib/env_has.mk $CVU_HOME/crs/lib/env_has.mk
chmod 664 $CVU_HOME/crs/lib/env_has.mk
mv $CVU_HOME/cv/admin/cvunetquery $CVU_HOME/cv/admin/cvunetquery.orig
cp -p cv/admin/cvunetquery $CVU_HOME/cv/admin/cvunetquery
chmod 775 $CVU_HOME/cv/admin/cvunetquery
mv $CVU_HOME/cv/cvdata/ora_software_cfg.xml $CVU_HOME/cv/cvdata/ora_software_cfg.xml.orig
cp -p cv/cvdata/ora_software_cfg.xml $CVU_HOME/cv/cvdata/ora_software_cfg.xml
chmod 664 $CVU_HOME/cv/cvdata/ora_software_cfg.xml
mv $CVU_HOME/cv/cvdata/pluggable.xml $CVU_HOME/cv/cvdata/pluggable.xml.orig
cp -p cv/cvdata/pluggable.xml $CVU_HOME/cv/cvdata/pluggable.xml
chmod 555 $CVU_HOME/cv/cvdata/pluggable.xml
mv $CVU_HOME/cv/cvdata/101/crsinst_prereq.xml $CVU_HOME/cv/cvdata/101/crsinst_prereq.xml.orig
cp -p cv/cvdata/101/crsinst_prereq.xml $CVU_HOME/cv/cvdata/101/crsinst_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/101/crsinst_prereq.xml
mv $CVU_HOME/cv/cvdata/101/dbcfg_prereq.xml $CVU_HOME/cv/cvdata/101/dbcfg_prereq.xml.orig
cp -p cv/cvdata/101/dbcfg_prereq.xml $CVU_HOME/cv/cvdata/101/dbcfg_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/101/dbcfg_prereq.xml
mv $CVU_HOME/cv/cvdata/101/dbinst_prereq.xml $CVU_HOME/cv/cvdata/101/dbinst_prereq.xml.orig
cp -p cv/cvdata/101/dbinst_prereq.xml $CVU_HOME/cv/cvdata/101/dbinst_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/101/dbinst_prereq.xml
mv $CVU_HOME/cv/cvdata/102/crsinst_prereq.xml $CVU_HOME/cv/cvdata/102/crsinst_prereq.xml.orig
cp -p cv/cvdata/102/crsinst_prereq.xml $CVU_HOME/cv/cvdata/102/crsinst_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/102/crsinst_prereq.xml
mv $CVU_HOME/cv/cvdata/102/dbcfg_prereq.xml $CVU_HOME/cv/cvdata/102/dbcfg_prereq.xml.orig
cp -p cv/cvdata/102/dbcfg_prereq.xml $CVU_HOME/cv/cvdata/102/dbcfg_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/102/dbcfg_prereq.xml
mv $CVU_HOME/cv/cvdata/102/dbinst_prereq.xml $CVU_HOME/cv/cvdata/102/dbinst_prereq.xml.orig
cp -p cv/cvdata/102/dbinst_prereq.xml $CVU_HOME/cv/cvdata/102/dbinst_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/102/dbinst_prereq.xml
mv $CVU_HOME/cv/cvdata/111/crsinst_prereq.xml $CVU_HOME/cv/cvdata/111/crsinst_prereq.xml.orig
cp -p cv/cvdata/111/crsinst_prereq.xml $CVU_HOME/cv/cvdata/111/crsinst_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/111/crsinst_prereq.xml
mv $CVU_HOME/cv/cvdata/111/dbcfg_prereq.xml $CVU_HOME/cv/cvdata/111/dbcfg_prereq.xml.orig
cp -p cv/cvdata/111/dbcfg_prereq.xml $CVU_HOME/cv/cvdata/111/dbcfg_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/111/dbcfg_prereq.xml
mv $CVU_HOME/cv/cvdata/111/dbinst_prereq.xml $CVU_HOME/cv/cvdata/111/dbinst_prereq.xml.orig
cp -p cv/cvdata/111/dbinst_prereq.xml $CVU_HOME/cv/cvdata/111/dbinst_prereq.xml
chmod 555 $CVU_HOME/cv/cvdata/111/dbinst_prereq.xml
mv $CVU_HOME/cv/cvdata/121/ora_software_cfg.xml $CVU_HOME/cv/cvdata/121/ora_software_cfg.xml.orig
cp -p cv/cvdata/121/ora_software_cfg.xml $CVU_HOME/cv/cvdata/121/ora_software_cfg.xml
chmod 664 $CVU_HOME/cv/cvdata/121/ora_software_cfg.xml
mv $CVU_HOME/cv/remenv/cvuqdisk-1.0.9-1.rpm $CVU_HOME/cv/remenv/cvuqdisk-1.0.9-1.rpm.orig
cp -p cv/remenv/cvuqdisk-1.0.9-1.rpm $CVU_HOME/cv/remenv/cvuqdisk-1.0.9-1.rpm
chmod 664 $CVU_HOME/cv/remenv/cvuqdisk-1.0.9-1.rpm
mv $CVU_HOME/cv/remenv/exectask $CVU_HOME/cv/remenv/exectask.orig
cp -p cv/remenv/exectask $CVU_HOME/cv/remenv/exectask
chmod 777 $CVU_HOME/cv/remenv/exectask
mv $CVU_HOME/cv/remenv/pluggable/checkhugepage.sh $CVU_HOME/cv/remenv/pluggable/checkhugepage.sh.orig
cp -p cv/remenv/pluggable/checkhugepage.sh $CVU_HOME/cv/remenv/pluggable/checkhugepage.sh
chmod 555 $CVU_HOME/cv/remenv/pluggable/checkhugepage.sh
mv $CVU_HOME/cv/remenv/pluggable/checktmpfs.sh $CVU_HOME/cv/remenv/pluggable/checktmpfs.sh.orig
cp -p cv/remenv/pluggable/checktmpfs.sh $CVU_HOME/cv/remenv/pluggable/checktmpfs.sh
chmod 555 $CVU_HOME/cv/remenv/pluggable/checktmpfs.sh
mv $CVU_HOME/cv/remenv/pluggable/css_misscount.sh $CVU_HOME/cv/remenv/pluggable/css_misscount.sh.orig
cp -p cv/remenv/pluggable/css_misscount.sh $CVU_HOME/cv/remenv/pluggable/css_misscount.sh
chmod 555 $CVU_HOME/cv/remenv/pluggable/css_misscount.sh
mv $CVU_HOME/jlib/cvu.jar $CVU_HOME/jlib/cvu.jar.orig
cp -p jlib/cvu.jar $CVU_HOME/jlib/cvu.jar
chmod 664 $CVU_HOME/jlib/cvu.jar
mv $CVU_HOME/jlib/cvuhelper121.jar $CVU_HOME/jlib/cvuhelper121.jar.orig
cp -p jlib/cvuhelper121.jar $CVU_HOME/jlib/cvuhelper121.jar
chmod 777 $CVU_HOME/jlib/cvuhelper121.jar
mv $CVU_HOME/jlib/srvm.jar $CVU_HOME/jlib/srvm.jar.orig
cp -p jlib/srvm.jar $CVU_HOME/jlib/srvm.jar
chmod 664 $CVU_HOME/jlib/srvm.jar
mv $CVU_HOME/lib/libagfw12.so $CVU_HOME/lib/libagfw12.so.orig
cp -p lib/libagfw12.so $CVU_HOME/lib/libagfw12.so
chmod 775 $CVU_HOME/lib/libagfw12.so
mv $CVU_HOME/lib/libclsra12.so $CVU_HOME/lib/libclsra12.so.orig
cp -p lib/libclsra12.so $CVU_HOME/lib/libclsra12.so
chmod 775 $CVU_HOME/lib/libclsra12.so
mv $CVU_HOME/lib/libhasgen12.so $CVU_HOME/lib/libhasgen12.so.orig
cp -p lib/libhasgen12.so $CVU_HOME/lib/libhasgen12.so
chmod 775 $CVU_HOME/lib/libhasgen12.so
mv $CVU_HOME/lib/libocr12.so $CVU_HOME/lib/libocr12.so.orig
cp -p lib/libocr12.so $CVU_HOME/lib/libocr12.so
chmod 775 $CVU_HOME/lib/libocr12.so
mv $CVU_HOME/lib/libocrb12.so $CVU_HOME/lib/libocrb12.so.orig
cp -p lib/libocrb12.so $CVU_HOME/lib/libocrb12.so
chmod 775 $CVU_HOME/lib/libocrb12.so
mv $CVU_HOME/lib/libocrutl12.so $CVU_HOME/lib/libocrutl12.so.orig
cp -p lib/libocrutl12.so $CVU_HOME/lib/libocrutl12.so
chmod 775 $CVU_HOME/lib/libocrutl12.so
mv $CVU_HOME/oui/jlib/srvm.jar $CVU_HOME/oui/jlib/srvm.jar.orig
cp -p oui/jlib/srvm.jar $CVU_HOME/oui/jlib/srvm.jar
chmod 444 $CVU_HOME/oui/jlib/srvm.jar
mv $CVU_HOME/oui/jlib/srvmasm.jar $CVU_HOME/oui/jlib/srvmasm.jar.orig
cp -p oui/jlib/srvmasm.jar $CVU_HOME/oui/jlib/srvmasm.jar
chmod 444 $CVU_HOME/oui/jlib/srvmasm.jar
mv $CVU_HOME/oui/lib/linux/libsrvm12.so $CVU_HOME/oui/lib/linux/libsrvm12.so.orig
cp -p oui/lib/linux/libsrvm12.so $CVU_HOME/oui/lib/linux/libsrvm12.so
chmod 555 $CVU_HOME/oui/lib/linux/libsrvm12.so



